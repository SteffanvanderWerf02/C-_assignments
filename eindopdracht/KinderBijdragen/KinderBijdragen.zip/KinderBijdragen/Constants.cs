﻿/*
 * Naam: Steffan van der Werf
 * Datum : 10-06-2022
 * Korte beschrijving : maken ouderbijdragen programma voor een school
 * Opdracht: 2 
 * Bijgeleidende docent: Rob Loves
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KinderBijdragen
{
    internal static class Constants
    {
        public const string connectionString =@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\xampp\htdocs\Opdrachten\NHLStenden\C-_assignments\eindopdracht\KinderBijdragen\KinderBijdragen\Ouderbijdragen.mdf;Integrated Security=True;Connect Timeout=30";
    }
}
